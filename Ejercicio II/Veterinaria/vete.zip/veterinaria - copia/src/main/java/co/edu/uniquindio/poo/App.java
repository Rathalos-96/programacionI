package co.edu.uniquindio.poo;

/**
 * Hello world!
 *
 */
public class App {
    public static void main(String[] args) {
    System.out.println("Hello World!");
    Mascota m1 = new Mascota("Mateo","Perro","Bernes de la montaña","Masculino","Negro,blanco,cafe","1094957292",25,2);
    System.out.println(m1.getNombre());

    }
}
